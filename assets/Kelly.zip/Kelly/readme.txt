Thanks for downloading this theme!

Theme Name: Kelly
Theme URL: https://bootstrapmade.com/kelly-free-bootstrap-cv-resume-html-template/
Author: BootstrapMade
Author URL: https://bootstrapmade.com